package org.example;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class BarcodeScan {
    static int counter = 0;
    ProductGetter pg = new ProductGetter();
    DatabaseConnection dbConnection = new DatabaseConnection();
    String barcode = "";
    public void Procedure() {
        Scanner sc = new Scanner(System.in);
        barcode = sc.nextLine();
        if (barcode.length() != 13) {
            System.out.println("Niewłaściwy format");
            Procedure();
        }
        else {
            DatabaseCheck(barcode);
            Procedure();
        }
    }
        private void DatabaseCheck(String barcode) {
            String query = "SELECT * FROM napoje WHERE barcode = ?"; // Zakładając, że tabela nazywa się 'produkty' i kolumna 'kod_kreskowy'
            try (Connection connection = dbConnection.connect();
                 PreparedStatement preparedStatement = connection.prepareStatement(query)) {

                preparedStatement.setString(1, barcode);
                ResultSet resultSet = preparedStatement.executeQuery();

                if (resultSet.next()) {
                    counter++;
                    System.out.println("Produkt znaleziony: " + resultSet.getString("name"));
                    System.out.println(counter);
                } else {
                    System.out.println("Produkt nie znaleziony.");
                }
            } catch (SQLException e) {
                System.out.println("Błąd podczas sprawdzania produktu: " + e.getMessage());
            }
        }


    }



