package org.example;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        BarcodeScan bscan = new BarcodeScan();
        System.out.println("Rozpocznij skanowanie");



            bscan.Procedure();
        }
    }
