package org.example;

public class ProductGetter {
    public void getAProduct(){

    }
}
