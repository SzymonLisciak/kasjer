package org.example;

public class Barcode {

    public static Boolean isValidBarcode(String barcode) {
        /*if (barcode.length() == 13) {
            return true;
        }
        else {
            return false;
        }*/
        return barcode.length() == 13;


    };
}
