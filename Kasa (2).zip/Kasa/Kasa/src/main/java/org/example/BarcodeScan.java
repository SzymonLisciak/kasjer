package org.example;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class BarcodeScan {
    private Map<String, ProductInfo> productCounter = new HashMap<>();
    DatabaseConnection dbConnection = new DatabaseConnection();
    String barcode = "";

    public void Procedure() throws IOException, InterruptedException {
        Scanner sc = new Scanner(System.in);
        barcode = sc.nextLine();
        if (barcode.equals("RESET")) {
            new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            System.out.println("Koniec zakupów");
            System.out.println("Rozpocznij skanowanie");

            productCounter.clear();
            Procedure();

        } else if (!Barcode.isValidBarcode(barcode)) {//barcode.length() != 13  --> Barcode.validate(input)/Barcode.isCorrect(input)

            System.out.println("Niewłaściwy format");

            Procedure();
        } else {
            new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            DatabaseCheck(barcode);
            printReceipt();
            Procedure();
        }
    }

     private void DatabaseCheck(String barcode) {
        String query = "SELECT * FROM napoje WHERE barcode = ?";
        try (Connection connection = dbConnection.connect();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setString(1, barcode);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                String name = resultSet.getString("name");
                double price = resultSet.getDouble("price");


                productCounter.put(barcode, new ProductInfo(name, price, productCounter.getOrDefault(barcode, new ProductInfo(name, price, 0)).getCount() + 1));

                System.out.println("Produkt znaleziony: " + name);
                System.out.println("Liczba skanów dla tego produktu: " + productCounter.get(barcode).getCount());
            } else {
                System.out.println("Produkt nie znaleziony.");
            }
        } catch (SQLException e) {
            System.out.println("Błąd podczas sprawdzania produktu: " + e.getMessage());
        }
    }

    private void printReceipt() {
        System.out.println("--------------------- PARAGON ----------------------");
        System.out.printf("%-20s %-10s %-10s %-10s%n", "Nazwa", "Cena", "Ilość", "Razem");
        System.out.println("----------------------------------------------------");

        double total = 0;
        for (ProductInfo product : productCounter.values()) {
            double productTotal = product.getPrice() * product.getCount();
            System.out.printf("%-20s %-10.2f %-10d %-10.2f%n", product.getName(), product.getPrice(), product.getCount(), productTotal);
            total += productTotal;
        }

        System.out.println("----------------------------------------------------");
        System.out.printf("Suma:                                      %.2f%n", total);
        System.out.println("----------------------------------------------------");
        System.out.println("Wpisz RESET w celu rozpoczęcia nowej sesji");
    }


    private static class ProductInfo {
        private String name;
        private double price;
        private int count;

        public ProductInfo(String name, double price, int count) {
            this.name = name;
            this.price = price;
            this.count = count;
        }

        public String getName() {
            return name;
        }

        public double getPrice() {
            return price;
        }

        public int getCount() {
            return count;
        }
    }
}
